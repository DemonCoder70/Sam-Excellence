import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export function middleware(req: NextRequest) {
  const path = req.nextUrl.pathname;

  const premiumPaths = ["/dashboard", "/test", "/results"];
  const isPremiumPath = premiumPaths.some((p) => path.startsWith(p));

  if (isPremiumPath) {
    const token = req.cookies.get("sam_access")?.value;
    if (!token) {
      const url = req.nextUrl.clone();
      url.pathname = "/pricing";
      return NextResponse.redirect(url);
    }
  }

  if (path.startsWith("/admin")) {
    if (path === "/admin/login") return NextResponse.next();
    const admin = req.cookies.get("sam_admin")?.value;
    if (!admin) {
      const url = req.nextUrl.clone();
      url.pathname = "/admin/login";
      return NextResponse.redirect(url);
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/dashboard/:path*", "/test/:path*", "/results/:path*", "/admin/:path*"],
};
