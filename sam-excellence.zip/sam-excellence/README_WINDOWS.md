# SAM Excellence (Windows quick start)

This is a Next.js web app. It does NOT run by double-clicking index.html.
You run it like a normal web server and open it in Chrome at http://localhost:3000

## 1) Install prerequisites
- Install Node.js (LTS)

## 2) Setup Supabase
- Create a Supabase project
- Run SQL schema in `supabase_schema.sql` (replace with the SQL from chat)
- Create `.env.local` in the project root with:

  NEXT_PUBLIC_SITE_URL=http://localhost:3000
  NEXT_PUBLIC_SUPABASE_URL=...
  NEXT_PUBLIC_SUPABASE_ANON_KEY=...
  SUPABASE_SERVICE_ROLE_KEY=...
  PAYSTACK_SECRET_KEY=...
  ADMIN_PASSWORD=...

## 3) Install dependencies
Open PowerShell in the folder and run:
  npm install

## 4) Run locally
  npm run dev

Open Chrome:
  http://localhost:3000
  http://localhost:3000/subjects
  http://localhost:3000/admin/login
