"use client";

export default function Paywall() {
  return (
    <div style={{ border: "1px solid #ddd", padding: 16, borderRadius: 12 }}>
      <h3 style={{ fontSize: 18, fontWeight: 700 }}>🔒 Unlock full access</h3>
      <p style={{ marginTop: 8 }}>
        Get full lessons, all videos, weekly tests, monthly exams, and improvement plans.
      </p>
    </div>
  );
}
