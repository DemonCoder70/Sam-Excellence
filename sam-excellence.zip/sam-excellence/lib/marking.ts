function clean(s: string) {
  return s.trim().replace(/\s+/g, " ");
}

function parseFractionOrNumber(raw: string): number | null {
  const s = clean(raw).toLowerCase();
  const m = s.match(/-?\d+(\.\d+)?(\/-?\d+(\.\d+)?)?/);
  if (!m) return null;

  const token = m[0];
  if (token.includes("/")) {
    const [a, b] = token.split("/");
    const na = Number(a);
    const nb = Number(b);
    if (!Number.isFinite(na) || !Number.isFinite(nb) || nb === 0) return null;
    return na / nb;
  }

  const n = Number(token);
  return Number.isFinite(n) ? n : null;
}

function extractUnit(raw: string): string | null {
  const s = clean(raw);
  const m = s.match(/-?\d+(\.\d+)?(\/-?\d+(\.\d+)?)?/);
  if (!m) return null;
  const unit = clean(s.slice(m.index! + m[0].length));
  return unit ? unit : null;
}

function normalizeUnit(u: string): string {
  return u
    .toLowerCase()
    .replace(/\s+/g, "")
    .replace("per", "/")
    .replace("sec", "s");
}

function unitMatches(userUnit: string | null, allowedUnits: string[]): boolean {
  if (!allowedUnits.length) return true;
  if (!userUnit) return false;

  const nu = normalizeUnit(userUnit);
  const allowed = allowedUnits.map(normalizeUnit);

  const equiv = new Map<string, string[]>([
    ["m/s", ["ms^-1", "m·s^-1", "m*s^-1"]],
    ["m/s^2", ["ms^-2", "m·s^-2", "m*s^-2"]],
    ["n", ["newton"]],
    ["j", ["joule"]],
    ["w", ["watt"]],
    ["pa", ["pascal"]],
  ]);

  if (allowed.includes(nu)) return true;
  for (const a of allowed) {
    const e = equiv.get(a);
    if (e && e.map(normalizeUnit).includes(nu)) return true;
  }
  return false;
}

export type Grading = {
  mode?: "exact" | "numeric";
  tolerance_abs?: number;
  tolerance_pct?: number;
  units?: string[];
  units_required?: boolean;
};

export function markAnswer(params: {
  q_type: "mcq" | "short";
  userAnswer: string;
  correctAnswer: string;
  grading: Grading;
}): { isCorrect: boolean; reason?: string } {
  const user = clean(params.userAnswer);
  const correct = clean(params.correctAnswer);

  if (params.q_type === "mcq") {
    const ok = user.toUpperCase() === correct.toUpperCase();
    return { isCorrect: ok, reason: ok ? "match" : "mismatch" };
  }

  const mode = params.grading?.mode ?? "exact";

  if (mode === "numeric") {
    const uNum = parseFractionOrNumber(user);
    const cNum = parseFractionOrNumber(correct);
    if (uNum === null || cNum === null) {
      return { isCorrect: false, reason: "not_numeric" };
    }

    const tolAbs = params.grading?.tolerance_abs ?? 0;
    const tolPct = params.grading?.tolerance_pct ?? 0;

    const absOk = tolAbs > 0 ? Math.abs(uNum - cNum) <= tolAbs : false;
    const pctOk =
      tolPct > 0 ? Math.abs(uNum - cNum) <= (Math.abs(cNum) * tolPct) / 100 : false;

    const numericOk = (tolAbs > 0 || tolPct > 0) ? (absOk || pctOk) : (uNum === cNum);

    const allowedUnits = params.grading?.units ?? [];
    const unitsRequired = !!params.grading?.units_required;

    if (allowedUnits.length > 0 || unitsRequired) {
      const userUnit = extractUnit(user);
      const okUnit = unitMatches(userUnit, allowedUnits);
      if (!okUnit) return { isCorrect: false, reason: "unit_mismatch" };
      if (unitsRequired && !userUnit) return { isCorrect: false, reason: "unit_missing" };
    }

    return { isCorrect: numericOk, reason: numericOk ? "numeric_ok" : "numeric_outside_tol" };
  }

  return { isCorrect: user.toLowerCase() === correct.toLowerCase(), reason: "exact" };
}
