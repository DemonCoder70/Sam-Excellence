export async function paystackInitialize(email: string, amountZar: number, callbackUrl: string, metadata?: any) {
  const amountCents = Math.round(amountZar * 100);

  const res = await fetch("https://api.paystack.co/transaction/initialize", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      email,
      amount: amountCents,
      callback_url: callbackUrl,
      metadata,
    }),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Paystack init failed: ${text}`);
  }

  return res.json() as Promise<{ status: boolean; data: { authorization_url: string; reference: string } }>;
}

export async function paystackVerify(reference: string) {
  const res = await fetch(`https://api.paystack.co/transaction/verify/${reference}`, {
    headers: { Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}` },
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Paystack verify failed: ${text}`);
  }

  return res.json();
}
