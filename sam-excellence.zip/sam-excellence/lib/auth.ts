import { cookies } from "next/headers";
import { supabaseAdmin } from "./supabase-admin";
import { sha256 } from "./crypto";

const COOKIE_NAME = "sam_access";

export async function getPremiumCustomerId(): Promise<string | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get(COOKIE_NAME)?.value;
  if (!token) return null;

  const tokenHash = sha256(token);
  const sb = supabaseAdmin();

  const { data } = await sb
    .from("access_tokens")
    .select("customer_id, expires_at")
    .eq("token_hash", tokenHash)
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (!data) return null;

  const expires = new Date(data.expires_at).getTime();
  if (Date.now() > expires) return null;

  const { data: sub } = await sb
    .from("subscriptions")
    .select("status, current_period_end")
    .eq("customer_id", data.customer_id)
    .order("updated_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (!sub || sub.status !== "active") return null;

  return data.customer_id;
}

export const ACCESS_COOKIE_NAME = COOKIE_NAME;
