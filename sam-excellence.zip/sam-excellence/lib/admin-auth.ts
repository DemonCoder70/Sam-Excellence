import { cookies } from "next/headers";
import crypto from "crypto";

const ADMIN_COOKIE = "sam_admin";
const SECRET = process.env.ADMIN_PASSWORD || "dev";

function sign(value: string) {
  return crypto.createHmac("sha256", SECRET).update(value).digest("hex");
}

export async function isAdmin(): Promise<boolean> {
  const store = await cookies();
  const v = store.get(ADMIN_COOKIE)?.value;
  if (!v) return false;

  const [payload, sig] = v.split(".");
  if (!payload || !sig) return false;

  return sign(payload) === sig;
}

export async function setAdminCookie() {
  const store = await cookies();
  const payload = `admin:${Date.now()}`;
  const sig = sign(payload);
  store.set(ADMIN_COOKIE, `${payload}.${sig}`, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    expires: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
  });
}

export async function clearAdminCookie() {
  const store = await cookies();
  store.set(ADMIN_COOKIE, "", { path: "/", expires: new Date(0) });
}
