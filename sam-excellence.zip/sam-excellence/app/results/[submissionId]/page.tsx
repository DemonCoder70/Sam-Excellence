import Link from "next/link";
import { supabaseAdmin } from "@/lib/supabase-admin";
import { getPremiumCustomerId } from "@/lib/auth";
import { redirect } from "next/navigation";

export default async function ResultsPage({ params }: { params: { submissionId: string } }) {
  const customerId = await getPremiumCustomerId();
  if (!customerId) redirect("/pricing");

  const sb = supabaseAdmin();

  const { data: sub } = await sb
    .from("submissions")
    .select("id,test_id,score,total,submitted_at,customer_id")
    .eq("id", params.submissionId)
    .maybeSingle();

  if (!sub || sub.customer_id !== customerId) {
    return <div style={{ padding: 24 }}>Result not found.</div>;
  }

  const { data: test } = await sb.from("tests").select("title,type").eq("id", sub.test_id).maybeSingle();

  const { data: answers } = await sb
    .from("submission_answers")
    .select("question_id,is_correct,marks_awarded,answer_json")
    .eq("submission_id", sub.id);

  const { data: questions } = await sb
    .from("questions")
    .select("id,question_text,marks,solution_md,correct_answer_json,order_index")
    .eq("test_id", sub.test_id)
    .order("order_index", { ascending: true });

  const pct = sub.total > 0 ? Math.round((sub.score / sub.total) * 100) : 0;

  const incorrect = (questions ?? []).filter((q) => {
    const a = (answers ?? []).find((x) => x.question_id === q.id);
    return !a?.is_correct;
  });

  return (
    <div style={{ padding: 24, maxWidth: 900, margin: "0 auto" }}>
      <Link href="/subjects">← Back</Link>

      <h1 style={{ fontSize: 28, fontWeight: 900, marginTop: 10 }}>Results</h1>
      <p style={{ marginTop: 6 }}>
        {test?.type === "weekly" ? "Weekly Test" : "Monthly Exam"}: <b>{test?.title}</b>
      </p>

      <div style={{ marginTop: 12, border: "1px solid #ddd", borderRadius: 14, padding: 14 }}>
        <div style={{ fontSize: 18, fontWeight: 900 }}>
          Score: {sub.score}/{sub.total} ({pct}%)
        </div>
        <div style={{ marginTop: 6 }}>Submitted: {new Date(sub.submitted_at).toLocaleString()}</div>
      </div>

      <h2 style={{ fontSize: 18, fontWeight: 900, marginTop: 18 }}>Improvement plan</h2>
      {incorrect.length === 0 ? (
        <div style={{ marginTop: 10, border: "1px solid #ddd", borderRadius: 14, padding: 14 }}>
          ✅ Strong performance. Next step: attempt the next topic test or do a timed practice set.
        </div>
      ) : (
        <div style={{ marginTop: 10, border: "1px solid #ddd", borderRadius: 14, padding: 14 }}>
          <div style={{ fontWeight: 900 }}>Focus areas ({incorrect.length})</div>
          <div style={{ marginTop: 8 }}>
            Recommendation: Rewatch the lesson, then redo this test after 48 hours.
          </div>
        </div>
      )}

      <h2 style={{ fontSize: 18, fontWeight: 900, marginTop: 18 }}>Question review</h2>
      <div style={{ display: "grid", gap: 12, marginTop: 10 }}>
        {(questions ?? []).map((q, idx) => {
          const a = (answers ?? []).find((x) => x.question_id === q.id);
          const correct = String(q.correct_answer_json?.answer ?? "");
          const user = String((a as any)?.answer_json?.answer ?? "");
          const ok = !!a?.is_correct;

          return (
            <div key={q.id} style={{ border: "1px solid #ddd", borderRadius: 14, padding: 14 }}>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <div style={{ fontWeight: 900 }}>Q{idx + 1} {ok ? "✅" : "❌"}</div>
                <div style={{ fontWeight: 900 }}>{(a as any)?.marks_awarded ?? 0}/{q.marks}</div>
              </div>

              <div style={{ marginTop: 8, whiteSpace: "pre-wrap" }}>{q.question_text}</div>

              <div style={{ marginTop: 10 }}>
                <div><b>Your answer:</b> {user || "(blank)"}</div>
                <div><b>Correct answer:</b> {correct}</div>
              </div>

              {q.solution_md ? (
                <div style={{ marginTop: 10 }}>
                  <div style={{ fontWeight: 900 }}>Solution</div>
                  <div style={{ whiteSpace: "pre-wrap", marginTop: 6 }}>{q.solution_md}</div>
                </div>
              ) : null}
            </div>
          );
        })}
      </div>
    </div>
  );
}
