import Link from "next/link";

export default function Pricing() {
  return (
    <div style={{ padding: 24, maxWidth: 900, margin: "0 auto" }}>
      <Link href="/">← Home</Link>
      <h1 style={{ fontSize: 30, fontWeight: 900, marginTop: 12 }}>Pricing</h1>
      <div style={{ display: "grid", gap: 12, marginTop: 16 }}>
        <div style={{ border: "1px solid #ddd", borderRadius: 14, padding: 16 }}>
          <div style={{ fontWeight: 900, fontSize: 18 }}>Self-study</div>
          <div style={{ marginTop: 6 }}>R299 / month</div>
          <div style={{ marginTop: 10, opacity: 0.9 }}>Full lessons, all videos, weekly tests, monthly exams, dashboard.</div>
        </div>
        <div style={{ border: "1px solid #ddd", borderRadius: 14, padding: 16 }}>
          <div style={{ fontWeight: 900, fontSize: 18 }}>Hybrid</div>
          <div style={{ marginTop: 6 }}>R499 / month</div>
          <div style={{ marginTop: 10, opacity: 0.9 }}>Everything in Self-study + group support (future).</div>
        </div>
      </div>
    </div>
  );
}
