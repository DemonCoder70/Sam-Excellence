import Link from "next/link";

const subjects = [
  { name: "Mathematics", slug: "maths", grades: "Grade 8–12" },
  { name: "Physical Sciences", slug: "physical-sciences", grades: "Grade 10–12" },
];

export default function SubjectsPage() {
  return (
    <div style={{ padding: 24, maxWidth: 900, margin: "0 auto" }}>
      <Link href="/">← Home</Link>
      <h1 style={{ fontSize: 30, fontWeight: 900, marginTop: 12 }}>Subjects</h1>
      <p style={{ marginTop: 8 }}>Choose a subject to start learning.</p>

      <div style={{ display: "grid", gap: 12, marginTop: 18 }}>
        {subjects.map((s) => (
          <Link
            key={s.slug}
            href={`/${s.slug}`}
            style={{
              display: "block",
              border: "1px solid #ddd",
              borderRadius: 14,
              padding: 16,
              textDecoration: "none",
              color: "inherit",
            }}
          >
            <div style={{ fontSize: 18, fontWeight: 900 }}>{s.name}</div>
            <div style={{ marginTop: 6 }}>{s.grades}</div>
            <div style={{ marginTop: 10, fontWeight: 800 }}>Explore →</div>
          </Link>
        ))}
      </div>
    </div>
  );
}
