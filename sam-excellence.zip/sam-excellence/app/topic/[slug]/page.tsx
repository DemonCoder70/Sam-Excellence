import Link from "next/link";
import { supabasePublic } from "@/lib/supabase-server";
import { getPremiumCustomerId } from "@/lib/auth";
import Paywall from "@/components/Paywall";

export default async function TopicPage({ params }: { params: { slug: string } }) {
  const sb = supabasePublic();

  const { data: topic } = await sb
    .from("topics")
    .select("id,title,preview_md,full_md,is_preview_free")
    .eq("slug", params.slug)
    .maybeSingle();

  if (!topic) return <div style={{ padding: 24 }}>Topic not found.</div>;

  const isPremium = (await getPremiumCustomerId()) !== null;
  const unlocked = topic.is_preview_free || isPremium;

  const { data: videos } = await sb
    .from("topic_videos")
    .select("youtube_url,title,is_preview,order_index")
    .eq("topic_id", topic.id)
    .order("order_index", { ascending: true });

  const { data: testList } = await sb
    .from("tests")
    .select("id,type,title")
    .eq("topic_id", topic.id);

  const previewVideos = (videos ?? []).filter((v) => v.is_preview);

  return (
    <div style={{ padding: 24, maxWidth: 900, margin: "0 auto" }}>
      <Link href="/subjects">← Subjects</Link>
      <h1 style={{ fontSize: 28, fontWeight: 800, marginTop: 12 }}>{topic.title}</h1>

      <section style={{ marginTop: 18 }}>
        <h2 style={{ fontSize: 18, fontWeight: 800 }}>Preview</h2>
        <div style={{ whiteSpace: "pre-wrap", marginTop: 8 }}>{topic.preview_md}</div>

        <div style={{ marginTop: 16 }}>
          <h3 style={{ fontWeight: 800 }}>Preview videos</h3>
          <ul style={{ marginTop: 8 }}>
            {previewVideos.map((v, i) => (
              <li key={i} style={{ marginBottom: 6 }}>
                <a href={v.youtube_url} target="_blank" rel="noreferrer">
                  {v.title || v.youtube_url}
                </a>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section style={{ marginTop: 24 }}>
        {unlocked ? (
          <>
            <h2 style={{ fontSize: 18, fontWeight: 800 }}>Full lesson</h2>
            <div style={{ whiteSpace: "pre-wrap", marginTop: 8 }}>{topic.full_md}</div>

            <div style={{ marginTop: 18 }}>
              <h3 style={{ fontWeight: 900 }}>Tests</h3>
              <ul style={{ marginTop: 8 }}>
                {(testList ?? []).map((t) => (
                  <li key={t.id} style={{ marginBottom: 6 }}>
                    <a href={`/test/${t.id}`}>
                      {t.type === "weekly" ? "Weekly Test" : "Monthly Exam"}: {t.title}
                    </a>
                  </li>
                ))}
                {(testList ?? []).length === 0 && <li>No tests yet.</li>}
              </ul>
            </div>

            <div style={{ marginTop: 18 }}>
              <Link href="/dashboard">Go to Dashboard →</Link>
            </div>
          </>
        ) : (
          <>
            <Paywall />
            <form action="/api/paystack/initialize" method="POST" style={{ marginTop: 16 }}>
              <input type="hidden" name="plan" value="basic" />
              <input
                name="email"
                placeholder="Enter email to unlock"
                required
                style={{ padding: 10, borderRadius: 10, border: "1px solid #ddd", width: "100%", maxWidth: 420 }}
              />
              <button
                type="submit"
                style={{ marginTop: 10, padding: "10px 14px", borderRadius: 10, border: "1px solid #111", fontWeight: 700 }}
              >
                Pay & Unlock
              </button>
            </form>
          </>
        )}
      </section>
    </div>
  );
}
