import { redirect } from "next/navigation";
import { cookies } from "next/headers";
import { paystackVerify } from "@/lib/paystack";
import { supabaseAdmin } from "@/lib/supabase-admin";
import { randomToken, sha256 } from "@/lib/crypto";
import { ACCESS_COOKIE_NAME } from "@/lib/auth";

export default async function UnlockSuccess({ searchParams }: { searchParams: { reference?: string } }) {
  const reference = searchParams.reference;
  if (!reference) redirect("/pricing");

  const verified = await paystackVerify(reference);
  const status = verified?.data?.status;
  const email = verified?.data?.customer?.email;
  const plan = verified?.data?.metadata?.plan || "basic";

  if (status !== "success" || !email) redirect("/pricing");

  const sb = supabaseAdmin();

  const { data: existing } = await sb.from("customers").select("id").eq("email", email).maybeSingle();
  const customerId =
    existing?.id ?? (await sb.from("customers").insert({ email }).select("id").single()).data!.id;

  const periodEnd = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
  await sb.from("subscriptions").insert({
    customer_id: customerId,
    status: "active",
    plan,
    current_period_end: periodEnd.toISOString(),
  });

  const token = randomToken(32);
  const tokenHash = sha256(token);
  const tokenExpires = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);

  await sb.from("access_tokens").insert({
    customer_id: customerId,
    token_hash: tokenHash,
    expires_at: tokenExpires.toISOString(),
  });

  const cookieStore = await cookies();
  cookieStore.set(ACCESS_COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    expires: tokenExpires,
  });

  return (
    <div style={{ padding: 24 }}>
      <h1 style={{ fontSize: 26, fontWeight: 800 }}>✅ Payment successful</h1>
      <p style={{ marginTop: 8 }}>Your access is now unlocked.</p>
      <p style={{ marginTop: 12 }}>
        <a href="/subjects">Go to Subjects →</a>
      </p>
    </div>
  );
}
