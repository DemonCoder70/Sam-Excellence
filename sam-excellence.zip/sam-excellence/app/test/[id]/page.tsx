import Link from "next/link";
import { supabasePublic } from "@/lib/supabase-server";
import { getPremiumCustomerId } from "@/lib/auth";
import { redirect } from "next/navigation";

export default async function TestPage({ params }: { params: { id: string } }) {
  const premiumCustomerId = await getPremiumCustomerId();
  if (!premiumCustomerId) redirect("/pricing");

  const sb = supabasePublic();

  const { data: test } = await sb
    .from("tests")
    .select("id,title,type,time_limit_minutes,total_marks")
    .eq("id", params.id)
    .maybeSingle();

  if (!test) return <div style={{ padding: 24 }}>Test not found.</div>;

  const { data: questions } = await sb
    .from("questions")
    .select("id,q_type,question_text,options_json,marks,order_index")
    .eq("test_id", test.id)
    .order("order_index", { ascending: true });

  return (
    <div style={{ padding: 24, maxWidth: 900, margin: "0 auto" }}>
      <Link href="/subjects">← Back</Link>

      <h1 style={{ fontSize: 28, fontWeight: 900, marginTop: 10 }}>
        {test.type === "weekly" ? "Weekly Test" : "Monthly Exam"}: {test.title}
      </h1>
      <p style={{ marginTop: 6 }}>
        Time limit: <b>{test.time_limit_minutes} min</b>
      </p>

      <form action={`/api/test/${test.id}/submit`} method="POST" style={{ marginTop: 18 }}>
        {(questions ?? []).map((q, idx) => (
          <div key={q.id} style={{ border: "1px solid #ddd", borderRadius: 14, padding: 14, marginBottom: 12 }}>
            <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
              <div style={{ fontWeight: 900 }}>Q{idx + 1}</div>
              <div style={{ fontWeight: 900 }}>{q.marks} mark(s)</div>
            </div>

            <div style={{ marginTop: 8, whiteSpace: "pre-wrap" }}>{q.question_text}</div>

            {q.q_type === "mcq" ? (
              <div style={{ display: "grid", gap: 8, marginTop: 12 }}>
                {["A", "B", "C", "D"].map((opt) =>
                  q.options_json?.[opt] ? (
                    <label key={opt} style={{ display: "flex", gap: 10, alignItems: "center" }}>
                      <input type="radio" name={`q_${q.id}`} value={opt} required />
                      <span>
                        <b>{opt}.</b> {q.options_json[opt]}
                      </span>
                    </label>
                  ) : null
                )}
              </div>
            ) : (
              <input
                name={`q_${q.id}`}
                placeholder="Type your answer"
                required
                style={{ marginTop: 12, padding: 10, borderRadius: 10, border: "1px solid #ddd", width: "100%" }}
              />
            )}
          </div>
        ))}

        <button type="submit" style={{ padding: "10px 14px", borderRadius: 10, border: "1px solid #111", fontWeight: 900 }}>
          Submit
        </button>
      </form>
    </div>
  );
}
