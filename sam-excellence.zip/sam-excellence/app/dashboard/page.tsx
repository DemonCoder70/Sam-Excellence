import Link from "next/link";
import { redirect } from "next/navigation";
import { getPremiumCustomerId } from "@/lib/auth";
import { supabaseAdmin } from "@/lib/supabase-admin";

function pct(score: number, total: number) {
  if (!total) return 0;
  return Math.round((score / total) * 100);
}

function band(p: number) {
  if (p >= 75) return "🟢 Strong";
  if (p >= 55) return "🟡 Improving";
  return "🔴 Needs work";
}

export default async function DashboardPage() {
  const customerId = await getPremiumCustomerId();
  if (!customerId) redirect("/pricing");

  const sb = supabaseAdmin();

  const { data: subs } = await sb
    .from("submissions")
    .select("id,test_id,score,total,submitted_at")
    .eq("customer_id", customerId)
    .order("submitted_at", { ascending: false })
    .limit(50);

  const submissions = subs ?? [];

  const testIds = Array.from(new Set(submissions.map((s) => s.test_id)));
  const { data: tests } = testIds.length
    ? await sb.from("tests").select("id,title,type,topic_id").in("id", testIds)
    : { data: [] as any[] };

  const testsById = new Map((tests ?? []).map((t) => [t.id, t]));

  const topicIds = Array.from(new Set((tests ?? []).map((t) => t.topic_id).filter(Boolean)));
  const { data: topics } = topicIds.length
    ? await sb.from("topics").select("id,title,slug,grade,term").in("id", topicIds)
    : { data: [] as any[] };

  const topicsById = new Map((topics ?? []).map((t) => [t.id, t]));

  const taken = submissions.length;
  const avg = taken === 0 ? 0 : Math.round(submissions.reduce((a, s) => a + pct(s.score, s.total), 0) / taken);
  const best = taken === 0 ? 0 : Math.max(...submissions.map((s) => pct(s.score, s.total)));

  const trend = submissions.slice(0, 10).reverse().map((s) => ({
    id: s.id,
    p: pct(s.score, s.total),
    date: new Date(s.submitted_at).toLocaleDateString(),
  }));

  const withTopic = submissions
    .map((s) => {
      const t = testsById.get(s.test_id);
      if (!t?.topic_id) return null;
      return { ...s, topic_id: t.topic_id };
    })
    .filter(Boolean) as any[];

  const latestByTopic = new Map<string, any>();
  for (const s of withTopic) {
    if (!latestByTopic.has(s.topic_id)) latestByTopic.set(s.topic_id, s);
  }

  const mastery = Array.from(latestByTopic.entries()).map(([topicId, s]) => {
    const topic = topicsById.get(topicId);
    const p = pct(s.score, s.total);
    return {
      topicId,
      title: topic?.title ?? "Unknown topic",
      slug: topic?.slug ?? "",
      grade: topic?.grade,
      term: topic?.term,
      p,
      band: band(p),
      last: new Date(s.submitted_at).toLocaleDateString(),
    };
  });

  mastery.sort((a, b) => a.p - b.p);
  const nextActions = mastery.slice(0, 3);

  return (
    <div style={{ padding: 24, maxWidth: 1000, margin: "0 auto" }}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
        <div>
          <h1 style={{ fontSize: 30, fontWeight: 900 }}>Dashboard</h1>
          <p style={{ marginTop: 6 }}>Your progress, trends, and next steps.</p>
        </div>
        <div style={{ marginTop: 6 }}>
          <Link href="/subjects">Back to learning →</Link>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: 12, marginTop: 16 }}>
        <div style={{ border: "1px solid #ddd", borderRadius: 14, padding: 14 }}>
          <div style={{ fontWeight: 900 }}>Tests taken</div>
          <div style={{ fontSize: 22, fontWeight: 900, marginTop: 6 }}>{taken}</div>
        </div>
        <div style={{ border: "1px solid #ddd", borderRadius: 14, padding: 14 }}>
          <div style={{ fontWeight: 900 }}>Average</div>
          <div style={{ fontSize: 22, fontWeight: 900, marginTop: 6 }}>{avg}%</div>
        </div>
        <div style={{ border: "1px solid #ddd", borderRadius: 14, padding: 14 }}>
          <div style={{ fontWeight: 900 }}>Best</div>
          <div style={{ fontSize: 22, fontWeight: 900, marginTop: 6 }}>{best}%</div>
        </div>
      </div>

      <div style={{ border: "1px solid #ddd", borderRadius: 14, padding: 14, marginTop: 16 }}>
        <div style={{ fontWeight: 900 }}>Recent trend (last {trend.length})</div>
        {trend.length === 0 ? (
          <div style={{ marginTop: 8 }}>No submissions yet. Take a test to start tracking.</div>
        ) : (
          <div style={{ marginTop: 10, display: "grid", gap: 8 }}>
            {trend.map((t) => (
              <div key={t.id} style={{ display: "flex", justifyContent: "space-between", border: "1px solid #eee", borderRadius: 12, padding: 10 }}>
                <div>{t.date}</div>
                <div style={{ fontWeight: 900 }}>{t.p}%</div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div style={{ border: "1px solid #ddd", borderRadius: 14, padding: 14, marginTop: 16 }}>
        <div style={{ fontWeight: 900 }}>Next actions</div>
        {nextActions.length === 0 ? (
          <div style={{ marginTop: 8 }}>Take a weekly test to unlock your improvement plan.</div>
        ) : (
          <ol style={{ marginTop: 10 }}>
            {nextActions.map((a) => (
              <li key={a.topicId} style={{ marginBottom: 10 }}>
                <div style={{ fontWeight: 900 }}>{a.band} — {a.title} ({a.p}%)</div>
                <div style={{ marginTop: 4 }}>
                  <a href={`/topic/${a.slug}`}>Revisit lesson →</a> • <span>Last attempt: {a.last}</span>
                </div>
              </li>
            ))}
          </ol>
        )}
      </div>

      <div style={{ border: "1px solid #ddd", borderRadius: 14, padding: 14, marginTop: 16 }}>
        <div style={{ fontWeight: 900 }}>Mastery by topic (latest score)</div>
        {mastery.length === 0 ? (
          <div style={{ marginTop: 8 }}>No topic mastery yet.</div>
        ) : (
          <div style={{ marginTop: 10, display: "grid", gap: 10 }}>
            {mastery.map((m) => (
              <div key={m.topicId} style={{ display: "flex", justifyContent: "space-between", gap: 12, border: "1px solid #eee", borderRadius: 12, padding: 12 }}>
                <div>
                  <div style={{ fontWeight: 900 }}>{m.title}</div>
                  <div style={{ marginTop: 4, opacity: 0.9 }}>Grade {m.grade} • Term {m.term} • Last: {m.last}</div>
                  <div style={{ marginTop: 6 }}>
                    <a href={`/topic/${m.slug}`}>Open topic →</a>
                  </div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ fontSize: 18, fontWeight: 900 }}>{m.p}%</div>
                  <div style={{ marginTop: 4 }}>{m.band}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
