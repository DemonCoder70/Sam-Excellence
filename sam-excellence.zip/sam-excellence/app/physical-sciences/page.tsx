import Link from "next/link";

const grades = [10, 11, 12];

export default function PhysicalSciencesGradesPage() {
  return (
    <div style={{ padding: 24, maxWidth: 900, margin: "0 auto" }}>
      <Link href="/subjects">← Subjects</Link>
      <h1 style={{ fontSize: 30, fontWeight: 900, marginTop: 12 }}>Physical Sciences</h1>
      <p style={{ marginTop: 8 }}>Choose your grade.</p>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: 12, marginTop: 18 }}>
        {grades.map((g) => (
          <Link
            key={g}
            href={`/physical-sciences/grade-${g}`}
            style={{
              border: "1px solid #ddd",
              borderRadius: 14,
              padding: 16,
              textDecoration: "none",
              color: "inherit",
              fontWeight: 900,
            }}
          >
            Grade {g} →
          </Link>
        ))}
      </div>
    </div>
  );
}
