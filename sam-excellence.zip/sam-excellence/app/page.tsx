import Link from "next/link";

export default function Home() {
  return (
    <div style={{ padding: 24, maxWidth: 900, margin: "0 auto" }}>
      <h1 style={{ fontSize: 34, fontWeight: 900, margin: 0 }}>SAM Excellence</h1>
      <p style={{ marginTop: 10 }}>
        Maths (Grade 8–12) • Physical Sciences (Grade 10–12) — preview lessons, then unlock full access.
      </p>

      <div style={{ display: "flex", gap: 12, marginTop: 16 }}>
        <Link href="/subjects" style={{ fontWeight: 900 }}>Start Learning →</Link>
        <Link href="/pricing" style={{ fontWeight: 900 }}>Pricing →</Link>
        <Link href="/admin" style={{ fontWeight: 900 }}>Admin →</Link>
      </div>
    </div>
  );
}
