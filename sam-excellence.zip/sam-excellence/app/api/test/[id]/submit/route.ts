import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase-admin";
import { getPremiumCustomerId } from "@/lib/auth";
import { markAnswer } from "@/lib/marking";

function norm(v: any) {
  return String(v ?? "").trim();
}

export async function POST(req: Request, ctx: { params: { id: string } }) {
  const customerId = await getPremiumCustomerId();
  if (!customerId) return NextResponse.redirect(new URL("/pricing", req.url));

  const testId = ctx.params.id;
  const form = await req.formData();
  const sb = supabaseAdmin();

  const { data: questions } = await sb
    .from("questions")
    .select("id,q_type,correct_answer_json,grading_json,marks")
    .eq("test_id", testId);

  if (!questions) return NextResponse.json({ error: "Failed to load questions" }, { status: 500 });

  const { data: submission } = await sb
    .from("submissions")
    .insert({ test_id: testId, customer_id: customerId, score: 0, total: 0 })
    .select("id")
    .single();

  let score = 0;
  let total = 0;

  for (const q of questions) {
    total += q.marks;
    const raw = form.get(`q_${q.id}`);
    const userAnswer = norm(raw);
    const correctAnswer = norm((q as any).correct_answer_json?.answer);

    const res = markAnswer({
      q_type: (q as any).q_type,
      userAnswer,
      correctAnswer,
      grading: (q as any).grading_json ?? {},
    });

    const marksAwarded = res.isCorrect ? q.marks : 0;
    score += marksAwarded;

    await sb.from("submission_answers").insert({
      submission_id: submission.id,
      question_id: q.id,
      answer_json: { answer: userAnswer, reason: res.reason },
      is_correct: res.isCorrect,
      marks_awarded: marksAwarded,
    });
  }

  await sb.from("submissions").update({ score, total }).eq("id", submission.id);
  return NextResponse.redirect(new URL(`/results/${submission.id}`, req.url));
}
