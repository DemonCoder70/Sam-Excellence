import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase-admin";
import { paystackVerify } from "@/lib/paystack";
import { randomToken, sha256 } from "@/lib/crypto";

export async function POST(req: Request) {
  const event = await req.json();
  const reference = event?.data?.reference;
  if (!reference) return NextResponse.json({ ok: true });

  const verified = await paystackVerify(reference);
  const status = verified?.data?.status;
  const email = verified?.data?.customer?.email;
  const plan = verified?.data?.metadata?.plan || "basic";

  if (status !== "success" || !email) return NextResponse.json({ ok: true });

  const sb = supabaseAdmin();

  const { data: existing } = await sb.from("customers").select("id").eq("email", email).maybeSingle();
  const customerId =
    existing?.id ?? (await sb.from("customers").insert({ email }).select("id").single()).data!.id;

  const periodEnd = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
  await sb.from("subscriptions").insert({
    customer_id: customerId,
    status: "active",
    plan,
    current_period_end: periodEnd.toISOString(),
  });

  const token = randomToken(32);
  const tokenHash = sha256(token);
  const tokenExpires = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);

  await sb.from("access_tokens").insert({
    customer_id: customerId,
    token_hash: tokenHash,
    expires_at: tokenExpires.toISOString(),
  });

  return NextResponse.json({ ok: true });
}
