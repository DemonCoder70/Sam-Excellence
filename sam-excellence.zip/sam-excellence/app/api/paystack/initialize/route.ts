import { NextResponse } from "next/server";
import { paystackInitialize } from "@/lib/paystack";

export async function POST(req: Request) {
  const form = await req.formData();
  const email = String(form.get("email") || "");
  const plan = String(form.get("plan") || "basic");

  if (!email.includes("@")) return NextResponse.json({ error: "Invalid email" }, { status: 400 });

  const amount = plan === "hybrid" ? 499 : 299;
  const callbackUrl = `${process.env.NEXT_PUBLIC_SITE_URL}/unlock/success`;

  const init = await paystackInitialize(email, amount, callbackUrl, { plan });
  return NextResponse.redirect(init.data.authorization_url);
}
