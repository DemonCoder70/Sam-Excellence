import Link from "next/link";
import { isAdmin } from "@/lib/admin-auth";
import { redirect } from "next/navigation";

export default async function AdminHome() {
  if (!(await isAdmin())) redirect("/admin/login");

  return (
    <div style={{ padding: 24, maxWidth: 900, margin: "0 auto" }}>
      <h1 style={{ fontSize: 30, fontWeight: 900 }}>Admin</h1>

      <div style={{ marginTop: 14, display: "grid", gap: 10 }}>
        <Link href="/admin/topics">Manage Topics →</Link>
        <Link href="/admin/tests">Manage Tests →</Link>

        <form action="/api/admin/logout" method="POST" style={{ marginTop: 10 }}>
          <button type="submit" style={{ padding: "10px 14px", borderRadius: 10, border: "1px solid #111", fontWeight: 900 }}>
            Logout
          </button>
        </form>
      </div>
    </div>
  );
}
