export default function TestEdit(){return <div style={{padding:24}}>Admin Test Edit: Please paste the full Test edit UI from chat into this file.</div>}
