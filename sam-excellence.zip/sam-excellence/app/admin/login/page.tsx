export default function AdminLoginPage() {
  return (
    <div style={{ padding: 24, maxWidth: 520, margin: "0 auto" }}>
      <h1 style={{ fontSize: 28, fontWeight: 900 }}>Admin Login</h1>
      <p style={{ marginTop: 8 }}>Enter admin password.</p>

      <form action="/api/admin/login" method="POST" style={{ marginTop: 16 }}>
        <input
          name="password"
          type="password"
          required
          placeholder="Admin password"
          style={{ width: "100%", padding: 10, borderRadius: 10, border: "1px solid #ddd" }}
        />
        <button
          type="submit"
          style={{ marginTop: 10, padding: "10px 14px", borderRadius: 10, border: "1px solid #111", fontWeight: 900 }}
        >
          Login
        </button>
      </form>
    </div>
  );
}
