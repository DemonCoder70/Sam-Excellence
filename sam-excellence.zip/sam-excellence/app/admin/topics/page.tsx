export default function Topics(){return <div style={{padding:24}}>Admin Topics: Please paste the full Topics UI from chat into this file.</div>}
