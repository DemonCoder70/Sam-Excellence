import Link from "next/link";

const TERMS = [1, 2, 3, 4];

function prettySubject(subject: string) {
  if (subject === "maths") return "Mathematics";
  if (subject === "physical-sciences") return "Physical Sciences";
  return subject;
}

export default function GradePage({ params }: { params: { subject: string; grade: string } }) {
  const subject = params.subject;
  const grade = Number(params.grade);

  return (
    <div style={{ padding: 24, maxWidth: 900, margin: "0 auto" }}>
      <Link href={`/${subject}`}>← {prettySubject(subject)}</Link>

      <h1 style={{ fontSize: 30, fontWeight: 900, marginTop: 12 }}>
        {prettySubject(subject)} — Grade {grade}
      </h1>
      <p style={{ marginTop: 8 }}>Choose a term to see topics.</p>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: 12, marginTop: 18 }}>
        {TERMS.map((t) => (
          <Link
            key={t}
            href={`/${subject}/grade-${grade}/term-${t}`}
            style={{
              border: "1px solid #ddd",
              borderRadius: 14,
              padding: 16,
              textDecoration: "none",
              color: "inherit",
              fontWeight: 900,
            }}
          >
            Term {t} →
          </Link>
        ))}
      </div>
    </div>
  );
}
