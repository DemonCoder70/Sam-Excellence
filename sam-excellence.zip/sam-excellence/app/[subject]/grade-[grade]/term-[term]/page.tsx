import Link from "next/link";
import { supabasePublic } from "@/lib/supabase-server";

function prettySubject(subject: string) {
  if (subject === "maths") return "Mathematics";
  if (subject === "physical-sciences") return "Physical Sciences";
  return subject;
}

export default async function TermTopicsPage({
  params,
}: {
  params: { subject: string; grade: string; term: string };
}) {
  const subjectSlug = params.subject;
  const grade = Number(params.grade);
  const term = Number(params.term);

  const sb = supabasePublic();

  const { data: subject } = await sb
    .from("subjects")
    .select("id,name,slug")
    .eq("slug", subjectSlug)
    .maybeSingle();

  if (!subject) {
    return (
      <div style={{ padding: 24 }}>
        <h1>Subject not found.</h1>
        <Link href="/subjects">Go back</Link>
      </div>
    );
  }

  const { data: topics, error } = await sb
    .from("topics")
    .select("title,slug,is_preview_free,order_index")
    .eq("subject_id", subject.id)
    .eq("grade", grade)
    .eq("term", term)
    .order("order_index", { ascending: true });

  return (
    <div style={{ padding: 24, maxWidth: 900, margin: "0 auto" }}>
      <Link href={`/${subjectSlug}/grade-${grade}`}>← Term selection</Link>

      <h1 style={{ fontSize: 30, fontWeight: 900, marginTop: 12 }}>
        {prettySubject(subjectSlug)} — Grade {grade}, Term {term}
      </h1>

      {error && (
        <p style={{ marginTop: 12 }}>
          Error loading topics: {String((error as any).message)}
        </p>
      )}

      <div style={{ display: "grid", gap: 10, marginTop: 18 }}>
        {(topics ?? []).length === 0 ? (
          <div style={{ border: "1px solid #ddd", borderRadius: 14, padding: 16 }}>
            <div style={{ fontWeight: 900 }}>No topics yet</div>
            <div style={{ marginTop: 6 }}>
              Add topics in Supabase (topics table) for this grade/term.
            </div>
          </div>
        ) : (
          topics!.map((t) => (
            <Link
              key={t.slug}
              href={`/topic/${t.slug}`}
              style={{
                border: "1px solid #ddd",
                borderRadius: 14,
                padding: 16,
                textDecoration: "none",
                color: "inherit",
                display: "block",
              }}
            >
              <div style={{ fontWeight: 900, fontSize: 16 }}>{t.title}</div>
              <div style={{ marginTop: 6 }}>
                {t.is_preview_free ? "🟢 Free" : "🔒 Preview available"}
              </div>
            </Link>
          ))
        )}
      </div>
    </div>
  );
}
